package com.surendramaran.yolov8tflite;
import static android.app.PendingIntent.getActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Login extends AppCompatActivity {
    EditText usernameField;
    EditText passwordField;
    ImageView hiddenButton;
    String username;
    String password;
    Button login;
    DatabaseReference mUserRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        hiddenButton = (ImageView) findViewById(R.id.ic_queen);
        usernameField = (EditText) findViewById(R.id.username_editText);
        passwordField = (EditText) findViewById(R.id.password_editText);
        hiddenButton.setClickable(true);


        hiddenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(Login.this, AddUser.class);
                startActivity(e);
            }
        });

        /* //Open Login Activity
        Button login = findViewById(R.id.login_button);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(Login.this, MainActivity.class);
                startActivity(e);
            }
        }); */

        //Open Register Activity
        Button register = findViewById(R.id.register_button);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(Login.this, AddUser.class);
                startActivity(e);
            }
        });
    }
}