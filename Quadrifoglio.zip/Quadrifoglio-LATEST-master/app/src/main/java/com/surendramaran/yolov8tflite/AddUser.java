package com.surendramaran.yolov8tflite;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

import org.checkerframework.checker.nullness.qual.NonNull;

public class AddUser extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private int userCount = 1;
    private EditText idnoAdd;
    private EditText emailAdd;
    private EditText usernameAdd;
    private EditText pwAdd;
    private EditText pwConf;
    private ProgressBar progressBar;

    private Button addButton;
    private DatabaseReference mUserRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        getSupportActionBar().setTitle("Register");

        Toast.makeText(AddUser.this, "You can register now", Toast.LENGTH_LONG).show();

        idnoAdd = findViewById(R.id.idno_add);
        emailAdd = findViewById(R.id.email_add);
        usernameAdd = findViewById(R.id.username_add);
        pwAdd = findViewById(R.id.pw_add);
        pwConf = findViewById(R.id.conf_pw_add);

        Button btnRegister = findViewById(R.id.register_button);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Obtain the entered data
                String username = usernameAdd.getText().toString();
                String email = emailAdd.getText().toString();
                String pw = pwAdd.getText().toString();
                String confpw = pwConf.getText().toString();
                String id_no = idnoAdd.getText().toString();

                if (TextUtils.isEmpty(username)) {
                    Toast.makeText(AddUser.this, "Please enter your full name...", Toast.LENGTH_LONG).show();
                    usernameAdd.setError("Full Name is required!");
                    usernameAdd.requestFocus();
                } else if (TextUtils.isEmpty(email)) {
                    Toast.makeText(AddUser.this, "Please enter your email...", Toast.LENGTH_LONG).show();
                    emailAdd.setError("Email is required!");
                    emailAdd.requestFocus();
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(AddUser.this, "Please enter your email...", Toast.LENGTH_LONG).show();
                    emailAdd.setError("Valid Email is required!");
                    emailAdd.requestFocus();
                } else if (TextUtils.isEmpty(pw)) {
                    Toast.makeText(AddUser.this, "Please enter your password...", Toast.LENGTH_LONG).show();
                    pwAdd.setError("Password is required");
                    pwAdd.requestFocus();
                } else if (pwAdd.length() < 6) {
                    Toast.makeText(AddUser.this, "Password should be at least 6 characters long", Toast.LENGTH_LONG).show();
                    pwAdd.setError("Password is too weak...");
                    pwAdd.requestFocus();
                } else if (TextUtils.isEmpty(confpw)) {
                    Toast.makeText(AddUser.this, "Please re-confirm your password...", Toast.LENGTH_LONG).show();
                    pwConf.setError("Password Confirmation is required");
                    pwConf.requestFocus();
                } else if (!pwAdd.equals(pwConf)) {
                    Toast.makeText(AddUser.this, "Please enter the same password... ", Toast.LENGTH_LONG).show();
                    pwConf.setError("Password Confirmation is required");
                    pwConf.requestFocus();
                    //Clear the enetered password
                    pwAdd.clearComposingText();
                    pwConf.clearComposingText();
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                    registerUser(String.valueOf(usernameAdd), String.valueOf(emailAdd), String.valueOf(pwAdd), String.valueOf(idnoAdd));
                }
            }
        });
    }

    private void registerUser(String usernameAdd, String emailAdd, String pwAdd, String idnoAdd)
    {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(emailAdd, pwAdd).addOnCompleteListener(AddUser.this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(AddUser.this, "User registered successfully", Toast.LENGTH_LONG).show();
                            FirebaseUser firebaseUser = auth.getCurrentUser();

                            //Send Verification Email
                            firebaseUser.sendEmailVerification();

                            /*//Open User Profile after successful registration
                            Intent intent = new Intent(AddUser.this,UserProfileActivity.class);
                            //To Prevent User from returning back to Register Activity on pressing back button after registration
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                                            | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish(); //to close Register Activity

                             */
                        }
                    }
                });
    }
}